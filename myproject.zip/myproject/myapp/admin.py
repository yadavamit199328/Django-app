from django.contrib import admin
from myapp.models import Start, Phoneno
# Register your models here.
admin.site.register(Start)
admin.site.register(Phoneno)